The following text document will contain instructions for executing the .ipynb files included in this zip file.


1. Need to change data file read path according to data file location.

# Load the dataset into a pandas DataFrame
df = pd.read_csv("/content/Banking Fraud.csv")

2. I have removed records in banking fraud and applied models on less data. The data files used for working on ML models are included in this zip file.