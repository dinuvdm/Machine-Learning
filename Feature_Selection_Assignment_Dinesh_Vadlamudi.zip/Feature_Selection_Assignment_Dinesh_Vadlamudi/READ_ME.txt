
1. All the .ipynb files are coded and  downloaded from Jupyter notebook.

2. Need to change the path to read the data file if data file is in differnt path.

Current path:

# Load the dataset into a pandas DataFrame
df = pd.read_csv('diabetes.csv') 

3.I  installed mlxtend library  for forward and backward feature selection in my Jupyter Notebook.

#Adding mlxtend lib 
!pip install mlxtend

