Source: 
https://www.kaggle.com/fedesoriano/stroke-prediction-dataset

Source Brain MRI: 
https://www.kaggle.com/sartajbhuvaji/brain-tumor-classification-mri

I didn't push the images to github. Download them from the link above.
Simple put the content of "Training" and "Testing" it into two folders under brain_mri called "training" and "testing". 